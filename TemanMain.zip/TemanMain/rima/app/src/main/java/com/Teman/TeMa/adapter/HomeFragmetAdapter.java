package com.Teman.TeMa.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.Teman.TeMa.fragment.GroupFragment;
import com.Teman.TeMa.fragment.PersonalFragment;

public class HomeFragmetAdapter extends FragmentPagerAdapter {
    public HomeFragmetAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {
        switch (i){
            case 0 :
                PersonalFragment personalFragment = new PersonalFragment();
                return personalFragment;
            case 1:
                GroupFragment groupFragment = new GroupFragment();
                return groupFragment;

        }
        return null;
    }

    @Override
    public int getCount() {
        return 2;
    }
}
